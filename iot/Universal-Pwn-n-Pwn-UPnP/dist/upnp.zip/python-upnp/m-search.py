import socket

TARGET = "127.0.0.1"

request = (
    "M-SEARCH * HTTP/1.1\r\n"
    f"HOST: {TARGET}:1900\r\n"
    'MAN: "ssdp:discover"\r\n'
    "MX: 2\r\n"
    "ST: ssdp:all\r\n"
    "\r\n"
)

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.settimeout(3)

sock.sendto(request.encode(), (TARGET, 1900))

data, addr = sock.recvfrom(4096)

print(data.decode())

