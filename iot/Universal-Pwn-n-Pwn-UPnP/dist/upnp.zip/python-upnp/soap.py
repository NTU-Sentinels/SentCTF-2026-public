import argparse
import requests

SERVICE_TYPE = "urn:schemas-upnp-org:service:DeviceConfig:1"
SOAP_ENDPOINT = "/upnp/control/deviceconfig"

def build_envelope(action, arguments):
    body = ""

    for key, value in arguments.items():
        body += f"<{key}>{value}</{key}>"

    return f"""<?xml version="1.0"?>
<s:Envelope
    xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"
    s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">

    <s:Body>

        <u:{action} xmlns:u="{SERVICE_TYPE}">
            {body}
        </u:{action}>

    </s:Body>

</s:Envelope>
"""


def send_request(host, port, action, arguments):
    url = f"http://{host}:{port}{SOAP_ENDPOINT}"

    headers = {
        "Content-Type": 'text/xml; charset="utf-8"',
        "SOAPAction": f'"{SERVICE_TYPE}#{action}"'
    }

    xml = build_envelope(action, arguments)

    print("\n===== Request =====")
    print(xml)

    response = requests.post(
        url,
        headers=headers,
        data=xml.encode()
    )

    print("\n===== Response =====\n s")
    print("Status:", response.status_code)
    print(response.text)


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("host")
    parser.add_argument(
        "--port",
        type=int,
        default=5000
    )

    parser.add_argument(
        "--action",
        required=True
    )

    parser.add_argument(
        "--arg",
        action="append",
        default=[],
        metavar="NAME=VALUE"
    )

    return parser.parse_args()


def main():
    args = parse_args()

    arguments = {}

    for item in args.arg:
        key, value = item.split("=", 1)
        arguments[key] = value

    send_request(
        args.host,
        args.port,
        args.action,
        arguments
    )


if __name__ == "__main__":
    main()