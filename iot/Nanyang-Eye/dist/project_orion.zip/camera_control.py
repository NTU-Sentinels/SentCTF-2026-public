#!/usr/bin/env python3
"""Recovered NANYANG-EYE-03 maintenance client.

Complete the marked values from the incident PCAP.  Use --dry-run on your own
computer; the physical Operations Console runs the same completed logic live.
"""
import argparse
import base64
import sys
import urllib.error
import urllib.parse
import urllib.request

GATEWAY = "http://gateway"

# TODO 1: Recover the HTTP Basic identity from the PCAP.
GATEWAY_USER = ""
GATEWAY_PASS = ""

# TODO 2: Recover the missing D-Link direction code from the PTZ request.
DIRECTION_CODES = {
    "up": 1, "up-right": 2, "right": None,
    "down-right": 8, "down": 7, "down-left": 6,
    "left": 3, "up-left": 0,
}
HORIZONTAL = {"up-left", "up-right", "left", "right", "down-left", "down-right"}
VERTICAL = {"up-left", "up", "up-right", "down-left", "down", "down-right"}


def build_move(direction, degrees):
    """TODO 3: Reconstruct the D-Link CGI form body from the PCAP."""
    return {}


def request(url, fields=None, dry_run=False):
    if not GATEWAY_USER or not GATEWAY_PASS:
        raise SystemExit("complete GATEWAY_USER and GATEWAY_PASS from the PCAP first")
    token = base64.b64encode(f"{GATEWAY_USER}:{GATEWAY_PASS}".encode()).decode()
    body = urllib.parse.urlencode(fields or {})
    if dry_run:
        print(f"POST {url}")
        print("Authorization: Basic " + token)
        print(body)
        return
    data = body.encode()
    headers = {"Authorization": "Basic " + token, "Content-Type": "application/x-www-form-urlencoded"}
    req = urllib.request.Request(url, data=data, method="POST", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            print(response.read().decode(errors="replace").strip())
    except urllib.error.HTTPError as exc:
        print(f"HTTP {exc.code}: " + exc.read().decode(errors="replace").strip(), file=sys.stderr)
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser(description="NANYANG-EYE-03 maintenance client")
    parser.add_argument("action", choices=["start", "home", *DIRECTION_CODES])
    parser.add_argument("degrees", type=int, nargs="?", help="relative PTZ step, 1..20")
    parser.add_argument("--host", default=GATEWAY, help="gateway URL (physical console only)")
    parser.add_argument("--dry-run", action="store_true", help="print request; do not contact a gateway")
    args = parser.parse_args()
    base = args.host.rstrip("/")
    if args.action == "start":
        if args.degrees is not None:
            parser.error("start does not take a degree value")
        request(base + "/camera/start", {}, args.dry_run)
        return
    if args.action == "home":
        if args.degrees is not None:
            parser.error("home does not take a degree value")
        request(base + "/home", {}, args.dry_run)
        return
    if args.degrees is None or not 1 <= args.degrees <= 20:
        parser.error("a movement needs an integer step from 1 through 20")
    request(base + "/setControlPanTilt", build_move(args.action, args.degrees), args.dry_run)


if __name__ == "__main__":
    main()
